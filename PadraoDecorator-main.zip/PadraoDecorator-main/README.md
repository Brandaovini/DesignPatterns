# PadraoDecorator
Padrão de software decorator
