public interface Burger {

    public String getToppings();
    public double getPrice();
}
