import java.util.List;

public interface IUser {

    List<String> getInfo();
    Double withdrawMoney(Bank bank);
}
